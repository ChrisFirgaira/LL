// Configuration file - DO NOT commit to version control
// Add this file to .gitignore

window.MAPBOX_TOKEN = 'pk.eyJ1IjoidmVuZGFibGVzIiwiYSI6ImNtZHNycWcxazBoZm4ya29ubnR6ZGY4NWkifQ.db2JuRNjd7tcV1YLTjAmIg';

// You can also add other sensitive configuration here
window.APP_CONFIG = {
    mapbox: {
        token: 'pk.eyJ1IjoidmVuZGFibGVzIiwiYSI6ImNtZHNycWcxazBoZm4ya29ubnR6ZGY4NWkifQ.db2JuRNjd7tcV1YLTjAmIg',
        style: 'mapbox://styles/mapbox/streets-v12'
    },
    api: {
        baseUrl: 'https://popattack.co.uk'
    }
};